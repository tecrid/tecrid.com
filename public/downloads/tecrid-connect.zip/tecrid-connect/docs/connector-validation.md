# Connector validation checklist

Use this checklist for every LIMS site and version.

1. Map product, SKU, lot, report number, dates, method, matrix, units, LOQ, exact result text, and numeric value without lossy conversion.
2. Confirm reservation occurs only after the laboratory knows which approved report will be rendered.
3. Confirm the TECRID and resolver URL appear on every intended page/template variant, including corrected reports.
4. Hash the exported final bytes and independently recompute the digest.
5. Verify canonical payload bytes are signed exactly once with the reviewed key.
6. Simulate timeout before reservation, timeout after reservation, failed signature, expired reservation, revoked routing token, duplicate finalization, and recipient-scope exceptions.
7. Confirm the LIMS audit trail stores both successful and failed attempts without secrets.
8. Confirm a correction appends a TECRID version and does not overwrite prior evidence.
9. Run at least 100 parallel shadow reports before production cutover.
10. Obtain laboratory QA, IT security, and document-control approval.
