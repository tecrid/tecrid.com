# Agent-guided TECRID integration

This is the shared execution contract for Codex, Claude Code, and other capable coding agents. The plain-language trigger is `integrate`.

## What the agent must discover first

Inspect before asking questions:

- target repository path and deployable service boundary;
- language, framework, package manager, environment-file conventions, test commands, CI, and secret-manager integration;
- existing authentication, organization, audit-log, queue, webhook, document, and API-client patterns;
- whether TECRID code or environment variables already exist;
- organization role and, for laboratories, the source system or LIMS.

If the role, target repository, or LIMS remains ambiguous, ask for those items once. Never ask the user to paste a TECRID API key or signing key into chat.

## Supported implementation shapes

Choose the smallest shape compatible with the target system:

1. **Embedded client** — add the TECRID client boundary to an existing portal or service.
2. **Sidecar connector** — deploy a small organization-owned integration service when the LIMS or portal cannot safely host the client.
3. **Manual pilot adapter** — use reviewed JSON/CSV inputs and the CLI for a bounded pilot before automating the release event.

Do not write directly to a production LIMS database. Use its approved API, event, export, scheduler, or middleware boundary.

## Deterministic preflight

From this repository:

```bash
npm install
npm run typecheck
npm test
npm run integrate -- --role ROLE --target /absolute/path --adapter ADAPTER --write-plan
```

`ADAPTER` is required only for laboratories and may be `generic`, `labware`, `labvantage`, or `starlims`. The command performs a read-only TECRID health check, detects the target stack, and writes a secret-free `TECRID-INTEGRATION-PLAN.json` to the target. It does not issue a TECRID or alter production infrastructure.

## Role contracts

### Laboratory

Implement a two-pass, release-controlled workflow:

1. Reserve a TECRID after technical approval but before final PDF rendering.
2. Add the identifier and resolver/QR data to the controlled report template.
3. Render the final PDF and calculate SHA-256 over the exact exported bytes.
4. Canonicalize the reviewed structured findings through TECRID.
5. Sign the exact canonical payload with the laboratory-controlled, ICS-reviewed Ed25519 key.
6. Finalize the reservation once and persist the response in the native audit trail.
7. Test timeouts, expired reservations, invalid signatures, duplicate finalization, corrections, revoked routing, and recipient-scope exceptions.

Production issuance remains locked until TECRID verifies the laboratory identity, competence evidence, issuance scope, signing-key control, and signing conformance.

### Brand or ingredient supplier

Implement portfolio access, laboratory routing by SKU, recipient-specific permissions, historical-report intake, and the optional public participant-profile link. A brand may organize and disclose evidence but may not rewrite a laboratory-issued record.

### Retailer, certifier, certification program, regulator, or government

Implement scoped evidence requests or intake, authority validation, exact-version freezing, package-fingerprint storage, exception handling, and portfolio monitoring. Missing evidence is an exception, not a passing result. TECRID validation does not make the recipient's procurement, certification, or regulatory decision.

## Secret and approval boundary

- Put `TECRID_API_KEY` in the target's approved secret manager or environment, never source control.
- Keep Ed25519 private keys inside the laboratory-controlled HSM, KMS, or approved keystore.
- Run `GET /api/v1/health` without credentials.
- Use `npm run cli -- doctor` only after the API key is present in the environment.
- Do not make production writes merely to prove connectivity. Use a reviewed pilot record and explicit approval.

## Completion standard

The work is not complete until the agent creates `TECRID-INTEGRATION-REPORT.md` containing:

- role, target service, adapter, and implementation shape;
- files and behavior changed;
- endpoints and events connected;
- secret locations by variable name only;
- tests and read-only checks actually run;
- human-only gates still open;
- production-write and deployment approvals still required;
- rollback instructions;
- a statement that no secret or private report was added to source control.

The report must distinguish **implemented**, **verified**, **blocked by a human gate**, and **not attempted**. Never call a configuration production-ready merely because it compiles.
