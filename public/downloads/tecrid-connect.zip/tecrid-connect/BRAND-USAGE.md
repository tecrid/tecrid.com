# TECRID brand-use guidance

The MIT license applies to this repository’s software. It does not grant a general license to adopt the TECRID name or mark as the name, logo, certification seal, or identity of another product, service, registry, or organization.

A participating organization may use the unmodified TECRID mark to truthfully link to its current canonical TECRID participant profile or to a specific TECRID record, subject to these conditions:

- the destination is an official `https://tecrid.com/...` URL;
- the surrounding text accurately describes the destination;
- the use does not imply certification, approval, safety, compliance, pass/fail status, or publication of private evidence;
- the mark is not altered, recolored, incorporated into another logo, or used to create a confusingly similar registry identity;
- the organization stops or corrects the use if the linked profile or authorization is no longer current.

Use `assets/tecrid-logo.png` for approved profile links. Do not use the registered-trademark symbol unless and until TECRID publishes authorization to do so.
