import type { ConnectorProfile, SourceSystem } from "../types.js";

const sharedSequence = [
  "Call POST /api/v1/report-reservations before rendering the final report.",
  "Map tecrid_identifier and tecrid_resolver_url into the approved report template; encode qrData if the template supports QR.",
  "Render the final PDF, compute its SHA-256 fingerprint, and canonicalize the structured findings.",
  "Sign the canonical payload with the laboratory's ICS-reviewed Ed25519 key.",
  "Finalize the reservation. Store the TECRID, fingerprint, response id, and any routing warning in the LIMS audit trail.",
];

export const connectorProfiles: Record<SourceSystem, ConnectorProfile> = {
  generic: {
    id: "generic",
    displayName: "Generic JSON or CSV",
    vendorCertified: false,
    outboundMechanisms: ["HTTPS JSON", "CSV export plus connector worker"],
    recommendedTrigger: "After technical review and before final report rendering",
    reserveMapping: { productName: "product_name", productSku: "product_sku", laboratoryReportNumber: "report_number" },
    reportTemplateFields: ["tecrid_identifier", "tecrid_resolver_url", "qrData"],
    finalizationSequence: sharedSequence,
    implementationBoundary: "Use when the LIMS can export structured results or invoke HTTPS. TECRID does not read a production database directly.",
  },
  labware: {
    id: "labware",
    displayName: "LabWare integration profile",
    vendorCertified: false,
    outboundMechanisms: ["REST/JSON", "XML", "CSV", "LabWare web services"],
    recommendedTrigger: "Configured report approval or release event",
    reserveMapping: { productName: "configured product field", productSku: "configured client SKU field", laboratoryReportNumber: "LabWare report identifier" },
    reportTemplateFields: ["tecrid_identifier", "tecrid_resolver_url", "qrData"],
    finalizationSequence: sharedSequence,
    implementationBoundary: "Starter mapping only. A LabWare administrator must bind site-specific objects, security, release events, and report templates.",
  },
  labvantage: {
    id: "labvantage",
    displayName: "LabVantage integration profile",
    vendorCertified: false,
    outboundMechanisms: ["RESTful web services", "SOAP web services", "bulk data export"],
    recommendedTrigger: "Configured sample or report release transaction",
    reserveMapping: { productName: "configured sample/product property", productSku: "configured customer SKU property", laboratoryReportNumber: "configured report reference" },
    reportTemplateFields: ["tecrid_identifier", "tecrid_resolver_url", "qrData"],
    finalizationSequence: sharedSequence,
    implementationBoundary: "Starter mapping only. A LabVantage administrator must preserve native business logic and audit-trail behavior.",
  },
  starlims: {
    id: "starlims",
    displayName: "STARLIMS integration profile",
    vendorCertified: false,
    outboundMechanisms: ["REST/OpenAPI through System Interfacing", "external reporting interface", "file transfer"],
    recommendedTrigger: "Approved final-report generation event",
    reserveMapping: { productName: "configured accession/product field", productSku: "configured external SKU field", laboratoryReportNumber: "STARLIMS report reference" },
    reportTemplateFields: ["tecrid_identifier", "tecrid_resolver_url", "qrData"],
    finalizationSequence: sharedSequence,
    implementationBoundary: "Starter mapping only. A STARLIMS administrator must configure System Interfacing, report delivery, and the site-specific data model.",
  },
};

export function getConnectorProfile(id: SourceSystem) {
  return connectorProfiles[id];
}
