import assert from "node:assert/strict";
import test from "node:test";
import { mkdtemp, readFile, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { TecridApiError, TecridClient } from "../src/client.js";
import { connectorProfiles } from "../src/adapters/profiles.js";
import { buildIntegrationPlan, inspectTarget, normalizeRole } from "../src/integration.js";

test("reserves a report and sends bearer authentication", async () => {
  const originalFetch = globalThis.fetch;
  let receivedUrl = "";
  let receivedAuth = "";
  globalThis.fetch = async (input, init) => {
    const received = new Request(input, init);
    receivedUrl = received.url;
    receivedAuth = received.headers.get("authorization") || "";
    return Response.json({ reservation: { id: "reservation_1", tecrid: "TECRID·LAB-26-ABCDEFGH" } }, { status: 201 });
  };
  try {
    const response = await new TecridClient("tec_live_test", "https://example.test").reserveReport({ productName: "Cacao", productSku: "CACAO-1" });
    assert.equal(response.reservation.tecrid, "TECRID·LAB-26-ABCDEFGH");
    assert.equal(receivedUrl, "https://example.test/api/v1/report-reservations");
    assert.equal(receivedAuth, "Bearer tec_live_test");
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("surfaces structured API failures", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => Response.json({ error: { message: "invalid" } }, { status: 400 });
  try {
    await assert.rejects(
      () => new TecridClient("tec_live_test").getInsights(),
      (error: unknown) => error instanceof TecridApiError && error.status === 400,
    );
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("keeps vendor profiles honest", () => {
  for (const id of ["labware", "labvantage", "starlims"] as const) {
    assert.equal(connectorProfiles[id].vendorCertified, false);
    assert.match(connectorProfiles[id].implementationBoundary, /Starter mapping only/);
    assert.ok(connectorProfiles[id].reportTemplateFields.includes("tecrid_identifier"));
  }
});

test("normalizes every public organization role to a bounded integration contract", () => {
  assert.equal(normalizeRole("lab"), "laboratory");
  assert.equal(normalizeRole("supplier"), "brand");
  assert.equal(normalizeRole("third-party-certifier"), "recipient");
  assert.equal(normalizeRole("unknown"), null);
});

test("inspects a target without reading or writing secrets", async () => {
  const target = await mkdtemp(join(tmpdir(), "tecrid-connect-test-"));
  await writeFile(join(target, "package.json"), JSON.stringify({ dependencies: { next: "16.0.0" } }));
  await writeFile(join(target, ".env.example"), "TECRID_API_KEY=\n");
  const inspection = await inspectTarget(target);
  assert.deepEqual(inspection.stack, ["node", "nextjs"]);
  assert.equal(inspection.packageManager, "npm");
  assert.equal(inspection.alreadyReferencesTecrid, true);
  assert.deepEqual(inspection.environmentFiles, [".env.example"]);
});

test("builds a laboratory plan that preserves human and production gates", async () => {
  const inspection = { target: "/tmp/lab", name: "lab", stack: ["node"], packageManager: "npm", environmentFiles: [], ci: [], alreadyReferencesTecrid: false };
  const plan = buildIntegrationPlan({ role: "laboratory", adapter: "labware", inspection, apiHealth: { reachable: true, status: 200 } });
  assert.equal(plan.adapter, "labware");
  assert.ok(plan.implementationTasks.includes("Reserve before final report rendering"));
  assert.ok(plan.humanGates.includes("Approve the first controlled production issuance"));
  assert.match(await readFile(join(process.cwd(), "integration-manifest.json"), "utf8"), /\"trigger\": \"integrate\"/);
});
