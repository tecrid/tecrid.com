# TECRID Connect

Open-source client, CLI, Claude Code MCP server, and LIMS connector profiles for [TECRID](https://tecrid.com): the neutral trust layer between laboratories, suppliers, brands, retailers, certification programs, government, and the public.

**TECRID stands for Test Evidence Credential Record Identifier.** A TECRID is a persistent identifier for a versioned laboratory evidence record. The canonical definition, trust boundary, privacy model, and role-by-role explanation live at [tecrid.com/what-is-a-tecrid](https://tecrid.com/what-is-a-tecrid).

This repository is designed around one narrow operational win: a laboratory issues one structured, signed report credential at final release; the brand receives a complete TECRID receipt in its own workspace; approved certifiers, retailers, or government programs receive their separately authorized scopes. No recipient has to download, rename, re-upload, OCR, or re-key the same PDF.

## Choose your implementation path

[![Brand setup](https://img.shields.io/badge/Start-Brand-1743E3)](docs/brand-profile-and-signature.md)
[![Laboratory setup](https://img.shields.io/badge/Start-Laboratory-1743E3)](examples/role-workflows.md#laboratory)
[![Retailer or certifier](https://img.shields.io/badge/Start-Retailer_or_certifier-1743E3)](examples/role-workflows.md#retailer-certification-program-or-government)
[![Claude Code](https://img.shields.io/badge/Agent-Claude_Code-111827)](CLAUDE.md)
[![Codex and coding agents](https://img.shields.io/badge/Agent-Codex_%26_others-111827)](AGENTS.md)
[![MCP tools](https://img.shields.io/badge/Connect-MCP-0F766E)](.mcp.json)

The role chips lead to bounded implementation instructions. Coding agents should read `AGENTS.md`; Claude Code should also read `CLAUDE.md`. Both files point back to the same role and integrity rules so platform-specific instructions do not silently diverge.

## One-word agent setup

1. Open this repository in the coding agent alongside the application or integration service that will connect to TECRID.
2. For Codex, use GPT-5.6 Sol with `max` reasoning when available. For Claude Code, use the highest-capability coding mode available to your account.
3. Type one word: `integrate`

Codex reads the checked-in `AGENTS.md`; Claude Code reads `CLAUDE.md`. Both send the agent to the same manifest-driven workflow. The agent inspects the target stack, asks once for any undiscoverable role or system details, runs the public API health check, implements the correct role boundary, tests it, and creates `TECRID-INTEGRATION-REPORT.md`.

The user still performs the identity-sensitive steps: signing in to TECRID, choosing the organization, placing credentials in an approved secret manager, approving deployment, and—for laboratories—authorizing the mapped LIMS release event and production issuance. The agent must never invent or expose those credentials.

For a deterministic preflight outside a coding-agent chat:

```bash
npm install
npm run integrate -- --role laboratory --target /path/to/lab-integration --adapter labware --write-plan
```

Supported roles are `laboratory`, `brand`, `supplier`, `retailer`, `certifier`, and `government`. The full contract and acceptance criteria are in [`docs/agent-integration.md`](docs/agent-integration.md). Codex project instructions are documented by [OpenAI](https://developers.openai.com/codex/guides/agents-md); Claude Code project memory is documented by [Anthropic](https://docs.anthropic.com/en/docs/claude-code/memory).

## What works in the production API

| Workflow | Production status |
|---|---|
| Reserve a TECRID before final report rendering | Live |
| Return report-template identifier, resolver URL, and QR payload | Live |
| Show an explicit reserved—not issued—resolver state | Live |
| Finalize the preprinted TECRID with final-PDF SHA-256 and Ed25519 proof | Live |
| Deliver a full controller receipt to the brand or supplier | Live |
| Fan out independently scoped recipient packages | Live |
| Portfolio insights with source TECRIDs and missing-analyte exceptions | Live |
| API upload of historical PDFs for laboratory claim | Live |
| Durable in-product notifications | Live |
| Outbound email notification | Not yet configured; requires a production sending provider |
| Vendor-certified LabWare, LabVantage, or STARLIMS package | Not yet; profiles in this repo are implementation starters |

## Five-minute setup

Requirements: Node.js 22.13 or later and a TECRID organization API key.

```bash
npm install
export TECRID_API_KEY='tec_live_…'
npm run cli -- doctor
npm run cli -- connector-plan --adapter labware
```

Create a local config without putting a secret in it:

```bash
npm run cli -- init
```

The API base defaults to `https://tecrid.com`. Set `TECRID_API_BASE` only for an authorized test environment.

## Claude Code

The checked-in `.mcp.json` starts a local stdio MCP server and reads `TECRID_API_KEY` from the environment. Claude Code asks for approval before using a project-scoped MCP server.

```bash
export TECRID_API_KEY='tec_live_…'
claude
```

Then run `/mcp` and enable `tecrid`. Available tools:

- `reserve_report_tecrid`
- `list_report_reservations`
- `finalize_report_tecrid`
- `import_legacy_report`
- `get_evidence_insights`
- `get_lims_connector_profile`

You can also register it explicitly:

```bash
claude mcp add --transport stdio --scope project --env TECRID_API_KEY="$TECRID_API_KEY" tecrid -- npx tsx src/mcp-server.ts
```

## The correct final-report sequence

1. Brand or supplier creates a routing token for a verified laboratory and SKU. External recipient grants are optional.
2. Laboratory calls `POST /api/v1/report-reservations` before rendering the report.
3. LIMS places `tecrid_identifier` and `tecrid_resolver_url` into the approved report template. The resolver URL is also the QR payload.
4. LIMS renders the final PDF and calculates SHA-256 over those exact bytes.
5. Laboratory canonicalizes the structured findings and signs that exact payload with its ICS-reviewed Ed25519 key.
6. Laboratory finalizes the reservation. The identifier printed on the PDF becomes the issued TECRID.
7. TECRID places the full signed receipt in the controller workspace and creates scoped recipient packages for every active grant.

This two-pass design avoids a circular hash: the identifier exists before the PDF, while the final PDF fingerprint exists only after the identifier is printed.

## CLI examples

Reserve from a JSON input:

```bash
npm run cli -- reserve --input examples/reserve-report.json
```

After report rendering and signature:

```bash
npm run cli -- finalize \
  --reservation reservation_… \
  --input examples/finalize-report.example.json
```

Import a historical report:

```bash
npm run cli -- legacy-import \
  --pdf /authorized/path/report.pdf \
  --metadata templates/legacy-report.metadata.json
```

The import response returns a laboratory confirmation path. Uploading is not issuance; the named laboratory still has to claim, reconcile, confirm, and sign.

## Organization roles

- Laboratories reserve, render, fingerprint, sign, finalize, revise, and revoke.
- Brands and ingredient suppliers authorize laboratory delivery by SKU, receive full controller receipts, and control each external recipient.
- Retailers, certification programs, and government workspaces request a precise SKU, purpose, analyte scope, and delivery mode.
- Every recipient gets its own frozen fingerprinted view. Permission for one recipient never implies permission for another.

See `examples/role-workflows.md` for implementation checklists.

## Put the TECRID profile in brand email signatures

A participating brand or supplier may use the official TECRID mark as a compact hyperlink to its canonical public participant profile—the organizational equivalent of a researcher linking an ORCID iD. The recommended presentation is:

> [TECRID mark] View **Organization name**’s TECRID profile

The link must resolve to `https://tecrid.com/participants/ORGANIZATION_CODE`. Public discoverability is opt-in; the profile link does not make private reports public and does not represent product certification, approval, safety, or compliance.

Use the unmodified transparent artwork at `assets/tecrid-logo.png`. Copy-ready HTML, plain-text fallbacks, email-client steps, website markup, privacy boundaries, and an AI implementation prompt are in [`docs/brand-profile-and-signature.md`](docs/brand-profile-and-signature.md).

## First connector profiles

The repo includes generic JSON/CSV plus LabWare, LabVantage, and STARLIMS profiles. These three are first implementation priorities, not a claim that public market data proves them to be the three most common LIMS products.

- LabWare publicly documents REST/JSON, XML, ASTM, HL7, and CSV integration options.
- LabVantage publicly documents REST and SOAP web services.
- STARLIMS publicly documents REST/OpenAPI System Interfacing and automated reporting to external systems.

Each laboratory still needs an authorized administrator to bind its site-specific objects, release event, report template, security model, and validation plan. TECRID should be called from the controlled release workflow; it should never write directly into a production LIMS database.

## Is it 10× better?

Potentially for the evidence handoff, not automatically for the entire laboratory workflow. Measure it in a pilot.

Record these timestamps for at least 100 reports:

- final technical approval
- TECRID reservation
- final PDF rendered
- TECRID finalized
- brand controller receipt created
- first recipient package created
- first exception opened and closed

Compare against the prior process:

```text
manual minutes per report = lab email + brand filing/keying + recipient upload/OCR/keying + verification callbacks
TECRID minutes per report = automated issuance + exception-review minutes
workflow improvement = manual minutes / TECRID minutes
```

A 10× claim is justified only when measured median human-touch time drops by at least 90% without increasing error, rework, or unresolved exceptions. Keep lab turnaround time, analytical work, and technical review outside this narrow claim unless those steps are separately measured.

## Security and integrity

- Never commit `tec_live_…`, `tec_route_…`, signing keys, private PDFs, or customer data.
- API and routing keys belong in a secret manager and are displayed once by TECRID.
- The registry stores API and routing tokens as one-way SHA-256 hashes.
- Only a verified laboratory may publish production TECRIDs.
- A controlled credential requires current controller authorization.
- Reservations expire; expired identifiers must not be reused.
- Insights are descriptive. They do not determine product safety, legal compliance, or comparability across units and methods.

## Development

```bash
npm run typecheck
npm test
npm run mcp
```

License: MIT.

The MIT license covers the software. Use of the TECRID name and mark is governed separately by [`BRAND-USAGE.md`](BRAND-USAGE.md).
