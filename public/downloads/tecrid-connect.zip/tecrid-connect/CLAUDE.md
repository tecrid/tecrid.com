# TECRID Connect — instructions for Claude Code

This repository connects an organization to the production TECRID API. Treat laboratory evidence as integrity-sensitive data.

## First actions

1. Run `npm install`, `npm test`, and `npm run typecheck`.
2. Confirm `TECRID_API_BASE` and `TECRID_API_KEY` are present. Never write the API key into source, fixtures, logs, or a report.
3. Run `npm run cli -- doctor` before a write operation.
4. Inspect the selected connector profile with `npm run cli -- connector-plan --adapter <adapter>`.

## Non-negotiable workflow

- Reserve before report rendering.
- Put the returned `tecrid_identifier` and resolver URL or QR data into the approved final-report template.
- Hash the finished PDF, not an earlier draft.
- Canonicalize and sign the exact structured credential after technical review.
- Finalize once. Store the response in the LIMS audit trail.
- Never describe a reservation, upload, draft, or failed finalization as an issued TECRID.
- Never infer pass/fail, product safety, legal compliance, or method comparability from portfolio insights.

## Legacy documents

Historical PDF intake is private and creates an invitation for the named laboratory. It does not establish laboratory participation or issue a TECRID. The laboratory must claim, reconcile, confirm, and sign.

## Integration boundary

The LabWare, LabVantage, and STARLIMS profiles are starters based on public vendor integration capabilities. They are not vendor-certified and must be mapped by an authorized LIMS administrator to the laboratory's actual data model, release controls, report templates, and validation procedures.
