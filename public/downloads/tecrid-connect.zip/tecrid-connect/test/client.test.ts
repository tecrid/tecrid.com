import assert from "node:assert/strict";
import test from "node:test";
import { TecridApiError, TecridClient } from "../src/client.js";
import { connectorProfiles } from "../src/adapters/profiles.js";

test("reserves a report and sends bearer authentication", async () => {
  const originalFetch = globalThis.fetch;
  let receivedUrl = "";
  let receivedAuth = "";
  globalThis.fetch = async (input, init) => {
    const received = new Request(input, init);
    receivedUrl = received.url;
    receivedAuth = received.headers.get("authorization") || "";
    return Response.json({ reservation: { id: "reservation_1", tecrid: "TECRID·LAB-26-ABCDEFGH" } }, { status: 201 });
  };
  try {
    const response = await new TecridClient("tec_live_test", "https://example.test").reserveReport({ productName: "Cacao", productSku: "CACAO-1" });
    assert.equal(response.reservation.tecrid, "TECRID·LAB-26-ABCDEFGH");
    assert.equal(receivedUrl, "https://example.test/api/v1/report-reservations");
    assert.equal(receivedAuth, "Bearer tec_live_test");
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("surfaces structured API failures", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => Response.json({ error: { message: "invalid" } }, { status: 400 });
  try {
    await assert.rejects(
      () => new TecridClient("tec_live_test").getInsights(),
      (error: unknown) => error instanceof TecridApiError && error.status === 400,
    );
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("keeps vendor profiles honest", () => {
  for (const id of ["labware", "labvantage", "starlims"] as const) {
    assert.equal(connectorProfiles[id].vendorCertified, false);
    assert.match(connectorProfiles[id].implementationBoundary, /Starter mapping only/);
    assert.ok(connectorProfiles[id].reportTemplateFields.includes("tecrid_identifier"));
  }
});
