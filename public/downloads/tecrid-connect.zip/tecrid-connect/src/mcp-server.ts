#!/usr/bin/env node
import { readFile } from "node:fs/promises";
import { basename } from "node:path";
import { McpServer } from "@modelcontextprotocol/server";
import { serveStdio } from "@modelcontextprotocol/server/stdio";
import * as z from "zod/v4";
import { TecridClient } from "./client.js";
import { getConnectorProfile } from "./adapters/profiles.js";
import type { CredentialInput, LegacyReportMetadata, ReserveReportInput, SourceSystem } from "./types.js";

function client() {
  return new TecridClient(process.env.TECRID_API_KEY || "", process.env.TECRID_API_BASE || "https://tecrid.com");
}

function result(value: unknown) {
  return { content: [{ type: "text" as const, text: JSON.stringify(value, null, 2) }] };
}

function failure(error: unknown) {
  return { content: [{ type: "text" as const, text: error instanceof Error ? error.message : String(error) }], isError: true };
}

function createServer() {
  const server = new McpServer({ name: "tecrid-connect", version: "0.1.0" });
  server.registerTool("reserve_report_tecrid", {
    description: "Reserve a production TECRID before the laboratory renders the final PDF. Returns report-template fields and resolver QR data.",
    inputSchema: z.object({
      productName: z.string().min(1),
      productSku: z.string().min(1),
      laboratoryReportNumber: z.string().optional(),
      sourceSystem: z.enum(["generic", "labware", "labvantage", "starlims"]).default("generic"),
      routingToken: z.string().optional(),
      expiresInHours: z.number().int().min(1).max(168).optional(),
    }),
  }, async (input) => {
    try { return result(await client().reserveReport(input as ReserveReportInput)); } catch (error) { return failure(error); }
  });
  server.registerTool("list_report_reservations", {
    description: "List report TECRID reservations belonging to the authenticated laboratory.",
    inputSchema: z.object({}),
  }, async () => {
    try { return result(await client().listReportReservations()); } catch (error) { return failure(error); }
  });
  server.registerTool("finalize_report_tecrid", {
    description: "Finalize a reserved TECRID from a reviewed credential JSON file after the final PDF is rendered, fingerprinted, and signed.",
    inputSchema: z.object({ reservationId: z.string().min(1), credentialJsonPath: z.string().min(1) }),
  }, async ({ reservationId, credentialJsonPath }) => {
    try {
      const input = JSON.parse(await readFile(credentialJsonPath, "utf8")) as CredentialInput;
      return result(await client().finalizeReport(reservationId, input));
    } catch (error) { return failure(error); }
  });
  server.registerTool("import_legacy_report", {
    description: "Upload a private historical laboratory PDF for laboratory claim and confirmation. Uploading does not issue a TECRID.",
    inputSchema: z.object({ pdfPath: z.string().min(1), metadataJsonPath: z.string().min(1) }),
  }, async ({ pdfPath, metadataJsonPath }) => {
    try {
      const [bytes, metadata] = await Promise.all([
        readFile(pdfPath),
        readFile(metadataJsonPath, "utf8").then((value) => JSON.parse(value) as LegacyReportMetadata),
      ]);
      return result(await client().importLegacyReport(basename(pdfPath), bytes, metadata));
    } catch (error) { return failure(error); }
  });
  server.registerTool("get_evidence_insights", {
    description: "Return deterministic portfolio summaries and source TECRIDs for the authenticated organization without inferring pass/fail or safety.",
    inputSchema: z.object({}),
  }, async () => {
    try { return result(await client().getInsights()); } catch (error) { return failure(error); }
  });
  server.registerTool("get_lims_connector_profile", {
    description: "Return an honest implementation starter for a generic, LabWare, LabVantage, or STARLIMS release workflow.",
    inputSchema: z.object({ adapter: z.enum(["generic", "labware", "labvantage", "starlims"]) }),
  }, async ({ adapter }) => result(getConnectorProfile(adapter as SourceSystem)));
  return server;
}

void serveStdio(createServer);
console.error("TECRID Connect MCP server running on stdio");
