# Role workflows

## Laboratory

- Complete ICS identity, scope, and signing-key verification.
- Create a live API key and store it in the laboratory secret manager.
- Bind reserve to the approved report-release workflow before PDF rendering.
- Add TECRID and resolver/QR fields to the controlled report template.
- Hash final PDF bytes, canonicalize results, sign, and finalize.
- Persist reservation id, TECRID, fingerprint, signature key id, API response, and routing warning in the native audit trail.

## Brand or ingredient supplier

- Create one laboratory routing token for a named verified lab and SKU.
- Keep the show-once token in the integration secret manager.
- Receive full controller receipts in Evidence routing and Insights.
- Approve certifier, retailer, or government requests independently; narrow when necessary.
- Revoke future delivery without pretending prior recipient receipts disappeared.

## Retailer, certification program, or government

- Request the exact controller organization code, SKU, purpose, analytes, and one-time or future delivery.
- Treat missing requested analytes as exceptions, never as passing results.
- Use `GET /api/v1/insights` for a portfolio summary and retain each source TECRID.
- Use certification intake for frozen append-only submission manifests.

## Historical reports

- Brand uploads the exact PDF and transcribes the results as received.
- TECRID fingerprints and stores the PDF privately.
- Named laboratory claims the invitation, reconciles discrepancies, and signs only if it can confirm the report.
- No upload, OCR, or brand assertion becomes laboratory authority by itself.
