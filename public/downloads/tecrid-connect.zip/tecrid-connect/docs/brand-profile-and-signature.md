# Brand TECRID profile and email signature

This guide is for brands and ingredient suppliers that have a TECRID organization profile. It adds a compact, verifiable profile link to ordinary correspondence in the same spirit that a researcher links an ORCID iD.

## Before adding the link

1. Confirm that the organization has joined TECRID.
2. Copy the canonical profile URL from the TECRID workspace. It should use this form:

   `https://tecrid.com/participants/ORGANIZATION_CODE`

3. Decide whether the organization wants its participant profile to be publicly discoverable. Discoverability is opt-in. A public participant profile does not make private TECRIDs, laboratory reports, findings, routing grants, or recipient packages public.
4. Use the official artwork without changing its shape, color, proportions, or internal T.

## Recommended signature

Display the mark at 18–20 pixels beside descriptive link text. Do not rely on the image alone because many email clients initially block remote images.

**Preferred text**

`View Example Brand’s TECRID profile`

**Plain-text fallback**

`TECRID profile: https://tecrid.com/participants/ORGANIZATION_CODE`

**Copy-ready HTML**

Replace `Example Brand` and `ORGANIZATION_CODE` before use.

```html
<table role="presentation" cellpadding="0" cellspacing="0" border="0">
  <tr>
    <td style="padding-right:6px;vertical-align:middle">
      <a href="https://tecrid.com/participants/ORGANIZATION_CODE">
        <img
          src="https://tecrid.com/brand/tecrid-logo.png"
          width="18"
          height="18"
          alt="TECRID"
          style="display:block;width:18px;height:18px;border:0"
        >
      </a>
    </td>
    <td style="vertical-align:middle;font:14px/1.4 Arial,sans-serif">
      <a
        href="https://tecrid.com/participants/ORGANIZATION_CODE"
        style="color:#1743e3;text-decoration:none"
      >View Example Brand’s TECRID profile</a>
    </td>
  </tr>
</table>
```

The same transparent artwork is included in this repository at `assets/tecrid-logo.png`. An email administrator may host or embed that file instead of loading it from `tecrid.com`, but the hyperlink itself should always use the canonical `tecrid.com/participants/...` profile URL.

## Add it to an email client

1. Open the email client’s signature editor.
2. Add the organization’s ordinary signature first.
3. Add the TECRID mark and the preferred text on one line beneath the organization details.
4. Hyperlink both the mark and text to the same canonical participant profile.
5. Send a test message to an external address. Confirm that the text remains useful when images are blocked and that the link resolves to the correct organization.

## Add it to a brand website

```html
<a href="https://tecrid.com/participants/ORGANIZATION_CODE">
  <img src="/path/to/tecrid-logo.png" width="20" height="20" alt="">
  <span>View Example Brand’s TECRID profile</span>
</a>
```

Keep a visible text label. The mark should identify the destination, not operate as an unexplained seal.

## Claims boundary

The TECRID mark means only that the link resolves to an official TECRID organization profile or record. It must not be presented as:

- “TECRID certified,” “TECRID approved,” or “TECRID safe”;
- proof that every product, SKU, lot, laboratory report, or finding is public;
- proof that a result passed a limit or that methods, units, matrices, or laboratories are comparable;
- an endorsement by TECRID or the Institute of Contaminant Standards.

On packaging, pair the mark with a specific TECRID resolver link or QR code and descriptive language such as `View laboratory evidence`. Do not use the profile mark as a blanket product claim.

## Prompt for a coding agent

Copy this prompt into Claude Code, Codex, Cursor, Copilot, or another repository-aware coding assistant:

```text
Add our official TECRID profile link to this project. First read AGENTS.md and docs/brand-profile-and-signature.md in tecrid/tecrid-connect. Use the unmodified TECRID artwork from assets/tecrid-logo.png. Link both the mark and visible text to https://tecrid.com/participants/ORGANIZATION_CODE. The visible text must say “View ORGANIZATION_NAME’s TECRID profile.” Preserve an accessible text fallback, keep the icon between 18 and 20 pixels in signatures, and do not make certification, approval, safety, compliance, pass/fail, or public-data claims. Do not expose API keys, private TECRIDs, reports, findings, routing grants, or recipient packages. Show me the exact files changed and verify the link target before finishing.
```

Replace `ORGANIZATION_CODE` and `ORGANIZATION_NAME` with the values from the organization’s TECRID workspace.
