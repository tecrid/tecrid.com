# Instructions for coding agents

This repository connects organizations to the production TECRID API. Read `README.md`, then use the narrowest role workflow that matches the task.

## The `integrate` trigger

When the user says `integrate`, or begins a request with `integrate`, treat that as a request to complete the agent-guided TECRID integration workflow in `docs/agent-integration.md`.

1. Read `docs/agent-integration.md` and `integration-manifest.json` before editing the target system.
2. Inspect the available workspace first. Do not ask the user for information that the codebase, environment, or TECRID health endpoint can answer.
3. Determine the organization role, target codebase, deployment shape, and—for laboratories—the LIMS adapter. If any remain ambiguous, ask once for the smallest missing set.
4. Run this repository's tests and the read-only integration preflight. Use `npm run integrate -- --role ROLE --target PATH --adapter ADAPTER --write-plan` only after the target path is known.
5. Implement the narrowest complete role workflow in the target codebase, including secret placeholders, API client boundaries, error handling, audit storage, and tests.
6. Run the target project's relevant checks. Create `TECRID-INTEGRATION-REPORT.md` in the target root with completed work, verified checks, human-only gates, and rollback instructions.

Typing `integrate` authorizes local, reversible code and configuration changes plus non-destructive validation. It does not authorize production issuance, creation or rotation of secrets, outbound messages, purchases, deployment, or changes to a production LIMS. Ask before any of those actions.

## Role entry points

- Brand or ingredient supplier identity, public profile, and email signature: `docs/brand-profile-and-signature.md`
- Laboratory issuance: `examples/role-workflows.md#laboratory`
- Retailer, certification program, or government intake: `examples/role-workflows.md#retailer-certification-program-or-government`
- Historical report intake: `examples/role-workflows.md#historical-reports`
- LIMS validation: `docs/connector-validation.md`
- Agent-guided integration contract: `docs/agent-integration.md`

## Brand-profile implementation contract

- Use `assets/tecrid-logo.png` unmodified.
- Link the mark and visible text to the canonical `https://tecrid.com/participants/ORGANIZATION_CODE` URL supplied by the organization.
- Use descriptive text such as `View Organization name’s TECRID profile`; do not ship a bare unexplained seal.
- A profile link does not make private records public and is not a certification, approval, safety, compliance, or pass/fail claim.
- Never expose API keys, signing keys, private TECRIDs, reports, findings, routing grants, or recipient packages.
- Verify the final URL and an image-blocked/plain-text fallback.

## Integrity rules

- Reserve before final report rendering.
- Hash the final PDF bytes, canonicalize the structured credential, sign after technical review, and finalize once.
- Never describe a reservation, upload, draft, or failed finalization as an issued TECRID.
- Never infer product safety, legal compliance, pass/fail, or analytical comparability from registry presence or portfolio insights.

## Before finishing

Run `npm install` when dependencies are absent, then `npm run typecheck` and `npm test`. Report any step that could not be verified.
