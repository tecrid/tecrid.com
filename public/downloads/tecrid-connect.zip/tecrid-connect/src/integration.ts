import { access, readFile } from "node:fs/promises";
import { basename, join, resolve } from "node:path";

export type IntegrationRole = "laboratory" | "brand" | "recipient";
export type IntegrationAdapter = "generic" | "labware" | "labvantage" | "starlims";

export type TargetInspection = {
  target: string;
  name: string;
  stack: string[];
  packageManager: string | null;
  environmentFiles: string[];
  ci: string[];
  alreadyReferencesTecrid: boolean;
};

const roleAliases: Record<string, IntegrationRole> = {
  laboratory: "laboratory", lab: "laboratory", issuer: "laboratory",
  brand: "brand", supplier: "brand", "ingredient-supplier": "brand",
  recipient: "recipient", retailer: "recipient", certifier: "recipient",
  "certification-body": "recipient", "third-party-certifier": "recipient",
  government: "recipient", regulator: "recipient",
};

export function normalizeRole(value: string): IntegrationRole | null {
  return roleAliases[value.trim().toLowerCase()] || null;
}

async function exists(path: string) {
  return access(path).then(() => true).catch(() => false);
}

export async function inspectTarget(targetPath: string): Promise<TargetInspection> {
  const target = resolve(targetPath);
  const stack: string[] = [];
  let packageManager: string | null = null;
  const packagePath = join(target, "package.json");
  if (await exists(packagePath)) {
    const pkg = JSON.parse(await readFile(packagePath, "utf8")) as { dependencies?: Record<string, string>; devDependencies?: Record<string, string> };
    const deps = { ...pkg.dependencies, ...pkg.devDependencies };
    stack.push("node");
    for (const [dependency, label] of [["next", "nextjs"], ["@nestjs/core", "nestjs"], ["express", "express"], ["hono", "hono"]] as const) {
      if (deps[dependency]) stack.push(label);
    }
    packageManager = await exists(join(target, "pnpm-lock.yaml")) ? "pnpm" : await exists(join(target, "yarn.lock")) ? "yarn" : "npm";
  }
  if (await exists(join(target, "pyproject.toml")) || await exists(join(target, "requirements.txt"))) stack.push("python");
  if (await exists(join(target, "pom.xml")) || await exists(join(target, "build.gradle"))) stack.push("java");
  if (await exists(join(target, "go.mod"))) stack.push("go");
  if (await exists(join(target, "Cargo.toml"))) stack.push("rust");

  const environmentCandidates = [".env.example", ".env.sample", "env.example", "wrangler.toml", "vercel.json", "vercel.ts"];
  const environmentFiles = (await Promise.all(environmentCandidates.map(async (file) => await exists(join(target, file)) ? file : null))).filter((file): file is string => Boolean(file));
  const ciCandidates = [".github/workflows", ".gitlab-ci.yml", "Jenkinsfile"];
  const ci = (await Promise.all(ciCandidates.map(async (file) => await exists(join(target, file)) ? file : null))).filter((file): file is string => Boolean(file));
  const searchable = ["package.json", ".env.example", "README.md", "pyproject.toml", "requirements.txt"];
  let alreadyReferencesTecrid = false;
  for (const file of searchable) {
    const path = join(target, file);
    if (await exists(path) && /tecrid/i.test(await readFile(path, "utf8"))) alreadyReferencesTecrid = true;
  }
  return { target, name: basename(target), stack: [...new Set(stack)], packageManager, environmentFiles, ci, alreadyReferencesTecrid };
}

export function buildIntegrationPlan(input: { role: IntegrationRole; adapter: IntegrationAdapter; inspection: TargetInspection; apiHealth: unknown }) {
  const common = ["Add TECRID_API_BASE and TECRID_API_KEY secret bindings without committing values", "Add a typed TECRID client boundary with structured error handling", "Persist evidence identifiers and version fingerprints in the native audit model", "Add read-only connectivity and authorization checks", "Add success, authorization, timeout, retry, and validation tests"];
  const roleTasks: Record<IntegrationRole, string[]> = {
    laboratory: ["Map the approved release event", "Reserve before final report rendering", "Render TECRID and resolver/QR fields", "Fingerprint final PDF bytes", "Canonicalize and sign with the reviewed Ed25519 key", "Finalize once and persist the issuer receipt"],
    brand: ["Read the governed evidence portfolio", "Create SKU-scoped laboratory routing", "Implement recipient-specific grants", "Support private historical-report intake", "Add the opt-in participant-profile link without certification claims"],
    recipient: ["Request or intake scoped TECRIDs", "Validate issuer authority and current record status", "Freeze the exact relied-upon version and package fingerprint", "Treat missing analytes as exceptions", "Keep TECRID validation separate from approval decisions"],
  };
  const humanGates: Record<IntegrationRole, string[]> = {
    laboratory: ["Complete ICS issuer verification", "Place the API key and private signing key in approved custody", "Obtain LIMS owner, QA, IT security, and document-control approval", "Approve the first controlled production issuance"],
    brand: ["Confirm organization membership", "Place the API key in the approved secret manager", "Approve each disclosure scope", "Approve deployment"],
    recipient: ["Confirm organization and program ownership", "Place the API key in the approved secret manager", "Approve the reliance and exception policy", "Approve deployment"],
  };
  return {
    schemaVersion: "1.0.0",
    generatedAt: new Date().toISOString(),
    role: input.role,
    adapter: input.role === "laboratory" ? input.adapter : null,
    apiBase: "https://tecrid.com",
    apiHealth: input.apiHealth,
    target: input.inspection,
    implementationTasks: [...common, ...roleTasks[input.role]],
    humanGates: humanGates[input.role],
    completionArtifact: "TECRID-INTEGRATION-REPORT.md",
    prohibited: ["Commit or log credentials", "Perform an unapproved production write", "Treat a reservation or upload as issuance", "Infer safety, compliance, certification, or pass/fail from registry presence"],
  };
}
