export type SourceSystem = "generic" | "labware" | "labvantage" | "starlims";

export type ResultRow = {
  analyte: string;
  symbol?: string;
  resultText: string;
  numericValue?: number | null;
  unit: string;
  loqText?: string;
  method?: string;
};

export type ReserveReportInput = {
  productName: string;
  productSku: string;
  laboratoryReportNumber?: string;
  sourceSystem?: SourceSystem;
  routingToken?: string;
  expiresInHours?: number;
};

export type ReportReservation = {
  id: string;
  tecrid: string;
  status: string;
  productName: string;
  productSku: string;
  expiresAt: string;
  reportMark: {
    humanReadable: string;
    resolverUrl: string;
    qrData: string;
    templateFields: {
      tecrid_identifier: string;
      tecrid_resolver_url: string;
    };
  };
  links: { resolver: string; finalize: string };
};

export type CredentialInput = {
  sampleName: string;
  productSku: string;
  lotNumber?: string;
  matrix?: string;
  method?: string;
  submittingParty?: string;
  collectedAt?: string;
  receivedAt?: string;
  testedAt?: string;
  releasedAt?: string;
  visibility: "public" | "controlled";
  publish: true;
  sourceDocument: {
    sha256: string;
    filename: string;
    reportNumber?: string;
    orderNumber?: string;
  };
  proof: {
    keyId: string;
    algorithm: "Ed25519";
    signature: string;
  };
  results: ResultRow[];
};

export type LegacyReportMetadata = {
  laboratoryName: string;
  laboratoryWebsite?: string;
  confirmationEmail: string;
  sampleName: string;
  lotNumber?: string;
  matrix?: string;
  method?: string;
  reportNumber?: string;
  orderNumber?: string;
  collectedAt?: string;
  receivedAt?: string;
  testedAt?: string;
  releasedAt?: string;
  results: ResultRow[];
};

export type ConnectorProfile = {
  id: SourceSystem;
  displayName: string;
  vendorCertified: false;
  outboundMechanisms: string[];
  recommendedTrigger: string;
  reserveMapping: Record<string, string>;
  reportTemplateFields: string[];
  finalizationSequence: string[];
  implementationBoundary: string;
};
