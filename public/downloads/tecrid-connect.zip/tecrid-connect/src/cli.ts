#!/usr/bin/env node
import { readFile, writeFile } from "node:fs/promises";
import { basename } from "node:path";
import { TecridClient } from "./client.js";
import { loadConfig } from "./config.js";
import { getConnectorProfile } from "./adapters/profiles.js";
import type { CredentialInput, LegacyReportMetadata, ReserveReportInput, SourceSystem } from "./types.js";

function argument(name: string) {
  const index = process.argv.indexOf(`--${name}`);
  return index >= 0 ? process.argv[index + 1] : undefined;
}

async function jsonFile<T>(path: string | undefined, label: string): Promise<T> {
  if (!path) throw new Error(`--${label} is required.`);
  return JSON.parse(await readFile(path, "utf8")) as T;
}

function output(value: unknown) {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

async function main() {
  const command = process.argv[2] || "help";
  if (command === "help") {
    process.stdout.write(`TECRID Connect\n\nCommands:\n  init\n  doctor\n  connector-plan --adapter labware|labvantage|starlims|generic\n  reserve --input reservation.json\n  finalize --reservation ID --input credential.json\n  insights\n  legacy-import --pdf report.pdf --metadata legacy.json\n`);
    return;
  }
  if (command === "init") {
    const path = argument("output") || "tecrid.config.json";
    await writeFile(path, `${JSON.stringify({ apiBase: "https://tecrid.com", adapter: "generic", defaultVisibility: "controlled", sourceSystem: "generic" }, null, 2)}\n`, { flag: "wx" });
    output({ created: path, next: "Export TECRID_API_KEY, then run tecrid-connect doctor." });
    return;
  }
  if (command === "connector-plan") {
    const adapter = (argument("adapter") || "generic") as SourceSystem;
    const profile = getConnectorProfile(adapter);
    if (!profile) throw new Error("Unknown adapter profile.");
    output(profile);
    return;
  }
  const config = await loadConfig(argument("config"));
  const apiKey = process.env.TECRID_API_KEY || "";
  const client = new TecridClient(apiKey, config.apiBase);
  if (command === "doctor") return output({ apiBase: config.apiBase, adapter: config.adapter, health: await client.health(), authenticated: await client.listCredentials().then(() => true) });
  if (command === "reserve") return output(await client.reserveReport(await jsonFile<ReserveReportInput>(argument("input"), "input")));
  if (command === "finalize") {
    const reservation = argument("reservation");
    if (!reservation) throw new Error("--reservation is required.");
    return output(await client.finalizeReport(reservation, await jsonFile<CredentialInput>(argument("input"), "input")));
  }
  if (command === "insights") return output(await client.getInsights());
  if (command === "legacy-import") {
    const pdf = argument("pdf");
    if (!pdf) throw new Error("--pdf is required.");
    const metadata = await jsonFile<LegacyReportMetadata>(argument("metadata"), "metadata");
    const bytes = await readFile(pdf);
    return output(await client.importLegacyReport(basename(pdf), bytes, metadata));
  }
  throw new Error(`Unknown command: ${command}`);
}

main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
});
