#!/usr/bin/env node
import { writeFile } from "node:fs/promises";
import { join } from "node:path";
import { buildIntegrationPlan, inspectTarget, normalizeRole, type IntegrationAdapter } from "./integration.js";

function argument(name: string) {
  const index = process.argv.indexOf(`--${name}`);
  return index >= 0 ? process.argv[index + 1] : undefined;
}

function hasFlag(name: string) {
  return process.argv.includes(`--${name}`);
}

async function health() {
  try {
    const response = await fetch("https://tecrid.com/api/v1/health", { signal: AbortSignal.timeout(10_000) });
    return { reachable: response.ok, status: response.status, body: await response.json().catch(() => null) };
  } catch (error) {
    return { reachable: false, status: null, error: error instanceof Error ? error.message : String(error) };
  }
}

async function main() {
  const roleInput = argument("role");
  if (!roleInput) {
    process.stdout.write(`${JSON.stringify({
      trigger: "integrate",
      status: "needs-role",
      supportedRoles: ["laboratory", "brand", "supplier", "retailer", "certifier", "government"],
      next: "Run with --role ROLE --target /absolute/path. Laboratories may also pass --adapter generic|labware|labvantage|starlims.",
    }, null, 2)}\n`);
    return;
  }
  const role = normalizeRole(roleInput);
  if (!role) throw new Error(`Unknown role: ${roleInput}`);
  const adapterInput = argument("adapter") || "generic";
  if (!(["generic", "labware", "labvantage", "starlims"] as string[]).includes(adapterInput)) throw new Error(`Unknown adapter: ${adapterInput}`);
  const inspection = await inspectTarget(argument("target") || process.cwd());
  const plan = buildIntegrationPlan({ role, adapter: adapterInput as IntegrationAdapter, inspection, apiHealth: await health() });
  if (hasFlag("write-plan")) {
    const path = join(inspection.target, "TECRID-INTEGRATION-PLAN.json");
    await writeFile(path, `${JSON.stringify(plan, null, 2)}\n`, { flag: "wx" });
    process.stdout.write(`${JSON.stringify({ status: "plan-created", path, plan }, null, 2)}\n`);
    return;
  }
  process.stdout.write(`${JSON.stringify({ status: "read-only-plan", plan }, null, 2)}\n`);
}

main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
});
