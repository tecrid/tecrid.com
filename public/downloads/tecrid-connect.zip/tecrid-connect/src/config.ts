import { readFile } from "node:fs/promises";

export type TecridConfig = {
  apiBase: string;
  adapter: "generic" | "labware" | "labvantage" | "starlims";
  defaultVisibility: "public" | "controlled";
  sourceSystem: "generic" | "labware" | "labvantage" | "starlims";
};

export async function loadConfig(path = "tecrid.config.json"): Promise<TecridConfig> {
  const defaults: TecridConfig = {
    apiBase: process.env.TECRID_API_BASE || "https://tecrid.com",
    adapter: "generic",
    defaultVisibility: "controlled",
    sourceSystem: "generic",
  };
  try {
    return { ...defaults, ...JSON.parse(await readFile(path, "utf8")) as Partial<TecridConfig> };
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return defaults;
    throw error;
  }
}
