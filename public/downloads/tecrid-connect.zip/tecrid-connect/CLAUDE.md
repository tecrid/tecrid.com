# TECRID Connect — instructions for Claude Code

This repository connects an organization to the production TECRID API. Treat laboratory evidence as integrity-sensitive data.

## When the user types `integrate`

Read `docs/agent-integration.md` and `integration-manifest.json`, inspect the available workspace, and carry out the role-aware integration contract. Ask only once for facts that cannot be discovered—normally the organization role, the target codebase path, and a laboratory's LIMS adapter. Then implement, test, and write `TECRID-INTEGRATION-REPORT.md` in the target root.

`integrate` authorizes reversible local code and configuration work and read-only checks. It does not authorize production TECRID issuance, secret creation or rotation, deployment, outbound communication, purchases, or direct production-LIMS changes. Ask before those actions. Never request an API or signing key in chat; direct the user to place it in an approved secret manager or environment.

## First actions

1. Run `npm install`, `npm test`, and `npm run typecheck`.
2. Confirm `TECRID_API_BASE` and `TECRID_API_KEY` are present. Never write the API key into source, fixtures, logs, or a report.
3. Run `npm run cli -- doctor` before a write operation.
4. Inspect the selected connector profile with `npm run cli -- connector-plan --adapter <adapter>`.
5. For a brand profile, website mark, or email signature, read `docs/brand-profile-and-signature.md` and use `assets/tecrid-logo.png` unmodified.

## Non-negotiable workflow

- Reserve before report rendering.
- Put the returned `tecrid_identifier` and resolver URL or QR data into the approved final-report template.
- Hash the finished PDF, not an earlier draft.
- Canonicalize and sign the exact structured credential after technical review.
- Finalize once. Store the response in the LIMS audit trail.
- Never describe a reservation, upload, draft, or failed finalization as an issued TECRID.
- Never infer pass/fail, product safety, legal compliance, or method comparability from portfolio insights.

## Legacy documents

Historical PDF intake is private and creates an invitation for the named laboratory. It does not establish laboratory participation or issue a TECRID. The laboratory must claim, reconcile, confirm, and sign.

## Brand profile and signature

Link both the TECRID mark and visible descriptive text to the organization’s canonical `https://tecrid.com/participants/ORGANIZATION_CODE` profile. A public participant profile is opt-in and does not make private reports or findings public. Never describe the profile mark as certification, approval, safety, compliance, or pass/fail evidence.

## Integration boundary

The LabWare, LabVantage, and STARLIMS profiles are starters based on public vendor integration capabilities. They are not vendor-certified and must be mapped by an authorized LIMS administrator to the laboratory's actual data model, release controls, report templates, and validation procedures.
