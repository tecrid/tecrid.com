import type { CredentialInput, LegacyReportMetadata, ReportReservation, ReserveReportInput } from "./types.js";

export class TecridApiError extends Error {
  constructor(public status: number, public body: unknown) {
    super(`TECRID API request failed with HTTP ${status}`);
  }
}

export class TecridClient {
  readonly apiBase: string;
  constructor(readonly apiKey: string, apiBase = "https://tecrid.com") {
    if (!apiKey) throw new Error("TECRID_API_KEY is required.");
    this.apiBase = apiBase.replace(/\/$/, "");
  }

  private async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    const headers = new Headers(init.headers);
    headers.set("authorization", `Bearer ${this.apiKey}`);
    if (init.body && !(init.body instanceof FormData)) headers.set("content-type", "application/json");
    const response = await fetch(`${this.apiBase}${path}`, { ...init, headers });
    const body = await response.json().catch(() => null) as unknown;
    if (!response.ok) throw new TecridApiError(response.status, body);
    return body as T;
  }

  health() {
    return fetch(`${this.apiBase}/api/v1/health`).then(async (response) => {
      if (!response.ok) throw new TecridApiError(response.status, await response.json().catch(() => null));
      return response.json();
    });
  }

  reserveReport(input: ReserveReportInput) {
    return this.request<{ reservation: ReportReservation }>("/api/v1/report-reservations", {
      method: "POST",
      body: JSON.stringify(input),
    });
  }

  listReportReservations() {
    return this.request<{ reservations: ReportReservation[]; count: number }>("/api/v1/report-reservations");
  }

  canonicalizeCredential(input: CredentialInput) {
    return this.request<{ canonicalPayload: string; normalizedCredential: unknown }>("/api/v1/credentials/canonicalize", {
      method: "POST",
      body: JSON.stringify(input),
    });
  }

  finalizeReport(reservationId: string, input: CredentialInput) {
    return this.request<Record<string, unknown>>(`/api/v1/report-reservations/${encodeURIComponent(reservationId)}/finalize`, {
      method: "POST",
      body: JSON.stringify(input),
    });
  }

  listCredentials() {
    return this.request<Record<string, unknown>>("/api/v1/credentials");
  }

  getInsights() {
    return this.request<Record<string, unknown>>("/api/v1/insights");
  }

  listLegacyReports() {
    return this.request<Record<string, unknown>>("/api/v1/legacy-reports");
  }

  async importLegacyReport(filename: string, bytes: Uint8Array, metadata: LegacyReportMetadata) {
    const form = new FormData();
    const copy = Uint8Array.from(bytes);
    form.set("document", new Blob([copy.buffer], { type: "application/pdf" }), filename);
    for (const [key, value] of Object.entries(metadata)) {
      if (key === "results") form.set("results", JSON.stringify(value));
      else if (value !== undefined) form.set(key, String(value));
    }
    form.set("attested", "on");
    return this.request<Record<string, unknown>>("/api/v1/legacy-reports", { method: "POST", body: form });
  }
}
